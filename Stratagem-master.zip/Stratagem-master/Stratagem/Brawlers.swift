import Foundation
import SpriteKit

class Brawlers: Units {
    override init() {
        super.init()
        health = 500
        damage = 50
    }
}
